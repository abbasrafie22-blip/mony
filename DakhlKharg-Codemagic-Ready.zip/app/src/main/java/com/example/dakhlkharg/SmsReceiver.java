package com.example.dakhlkharg;

import android.content.*;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.text.SimpleDateFormat;
import java.util.*;

public class SmsReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
  if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction())) return;
  SharedPreferences p=c.getSharedPreferences("finance",Context.MODE_PRIVATE);
  Set<String> seen=new HashSet<>(Arrays.asList(SmsParser.lines(p.getString("sms_ids",""))));
  for(SmsMessage sms: Telephony.Sms.Intents.getMessagesFromIntent(i)){
   String id=String.valueOf(sms.getTimestampMillis()); if(seen.contains(id)) continue;
   String sender=sms.getOriginatingAddress(); String body=sms.getMessageBody(); String rule=null;
   for(String r:SmsParser.lines(p.getString("sms_rules",""))) if(SmsParser.ruleMatches(r,sender)){rule=r;break;}
   if(rule==null) continue;
   SmsParser.Parsed ps=SmsParser.parse(body,rule); if(ps.amount<=0||ps.kind==0) continue;
   String card=matchCard(p,ps.cardSuffix); String m=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());
   String old=p.getString("tx",""); String line=(ps.kind==1?"I":"E")+"|"+ps.amount+"|"+ps.category+"|"+m+"|"+System.currentTimeMillis()+"|"+ps.note+"|"+card;
   p.edit().putString("tx",old.isEmpty()?line:old+"\n"+line).apply(); if(!card.isEmpty())adjust(p,card,ps.kind==1?ps.amount:-ps.amount); seen.add(id);
  }
  p.edit().putString("sms_ids",join(seen)).apply();
 }
 static String matchCard(SharedPreferences p,String suffix){if(suffix!=null&&!suffix.isEmpty())for(String x:SmsParser.lines(p.getString("cards",""))){String[]a=x.split("\\|",-1);if(a.length>=2&&a[1].replace(" ","").endsWith(suffix))return a[1];}return p.getString("selectedCard","");}
 static void adjust(SharedPreferences p,String card,long d){StringBuilder b=new StringBuilder();for(String x:SmsParser.lines(p.getString("cards",""))){String[]a=x.split("\\|",-1);if(a.length>=3&&a[1].equals(card))a[2]=String.valueOf(Long.parseLong(a[2])+d);x=String.join("|",a);if(b.length()>0)b.append('\n');b.append(x);}p.edit().putString("cards",b.toString()).apply();}
 static String join(Set<String>s){StringBuilder b=new StringBuilder();for(String x:s){if(b.length()>0)b.append('\n');b.append(x);}return b.toString();}
}
